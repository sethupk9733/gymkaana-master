
  # Marketplace Gym Owner Portal

  This is a code bundle for Marketplace Gym Owner Portal. The original project is available at https://www.figma.com/design/FTy0cHTWIKdlxkXBWS2TFM/Marketplace-Gym-Owner-Portal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  