import { useState } from "react";
import { Home, Building2, Calendar, User, Menu } from "lucide-react";
import { OwnerLogin } from "./components/OwnerLogin";
import { Dashboard } from "./components/Dashboard";
import { GymsList } from "./components/GymsList";
import { GymDetails } from "./components/GymDetails";
import { EditGym } from "./components/EditGym";
import { MembershipPlans } from "./components/MembershipPlans";
import { BookingsList } from "./components/BookingsList";
import { BookingDetails } from "./components/BookingDetails";
import { QRCheckIn } from "./components/QRCheckIn";
import { PayoutsEarnings } from "./components/PayoutsEarnings";
import { Notifications } from "./components/Notifications";
import { Profile } from "./components/Profile";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [currentScreen, setCurrentScreen] = useState("main");
  const [selectedGymId, setSelectedGymId] = useState<number | null>(null);
  const [selectedBookingId, setSelectedBookingId] = useState<number | null>(null);

  if (!isLoggedIn) {
    return <OwnerLogin onLogin={() => setIsLoggedIn(true)} />;
  }

  const handleGymSelect = (gymId: number) => {
    setSelectedGymId(gymId);
    setCurrentScreen("gymDetails");
  };

  const handleBookingSelect = (bookingId: number) => {
    setSelectedBookingId(bookingId);
    setCurrentScreen("bookingDetails");
  };

  const renderScreen = () => {
    if (currentScreen === "gymDetails" && selectedGymId !== null) {
      return (
        <GymDetails
          gymId={selectedGymId}
          onBack={() => setCurrentScreen("main")}
          onEdit={() => setCurrentScreen("editGym")}
          onManagePlans={() => setCurrentScreen("membershipPlans")}
        />
      );
    }

    if (currentScreen === "editGym") {
      return <EditGym onBack={() => setCurrentScreen("gymDetails")} />;
    }

    if (currentScreen === "membershipPlans") {
      return <MembershipPlans onBack={() => setCurrentScreen("gymDetails")} />;
    }

    if (currentScreen === "bookingDetails" && selectedBookingId !== null) {
      return (
        <BookingDetails
          bookingId={selectedBookingId}
          onBack={() => setCurrentScreen("main")}
        />
      );
    }

    if (currentScreen === "qrCheckIn") {
      return <QRCheckIn onBack={() => setCurrentScreen("main")} />;
    }

    if (currentScreen === "payouts") {
      return <PayoutsEarnings onBack={() => setCurrentScreen("main")} />;
    }

    if (currentScreen === "notifications") {
      return <Notifications onBack={() => setCurrentScreen("main")} />;
    }

    switch (activeTab) {
      case "dashboard":
        return (
          <Dashboard
            onNavigateToNotifications={() => setCurrentScreen("notifications")}
            onNavigateToPayouts={() => setCurrentScreen("payouts")}
            onNavigateToQR={() => setCurrentScreen("qrCheckIn")}
          />
        );
      case "gyms":
        return <GymsList onGymSelect={handleGymSelect} />;
      case "bookings":
        return <BookingsList onBookingSelect={handleBookingSelect} />;
      case "profile":
        return <Profile onLogout={() => setIsLoggedIn(false)} />;
      default:
        return <Dashboard onNavigateToNotifications={() => {}} onNavigateToPayouts={() => {}} onNavigateToQR={() => {}} />;
    }
  };

  const showBottomNav = currentScreen === "main";

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {renderScreen()}

      {showBottomNav && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-gray-300">
          <div className="max-w-md mx-auto grid grid-cols-4 h-16">
            <button
              onClick={() => {
                setActiveTab("dashboard");
                setCurrentScreen("main");
              }}
              className={`flex flex-col items-center justify-center gap-1 ${
                activeTab === "dashboard" ? "text-gray-900" : "text-gray-400"
              }`}
            >
              <Home size={20} />
              <span className="text-xs">Dashboard</span>
            </button>
            <button
              onClick={() => {
                setActiveTab("gyms");
                setCurrentScreen("main");
              }}
              className={`flex flex-col items-center justify-center gap-1 ${
                activeTab === "gyms" ? "text-gray-900" : "text-gray-400"
              }`}
            >
              <Building2 size={20} />
              <span className="text-xs">Gyms</span>
            </button>
            <button
              onClick={() => {
                setActiveTab("bookings");
                setCurrentScreen("main");
              }}
              className={`flex flex-col items-center justify-center gap-1 ${
                activeTab === "bookings" ? "text-gray-900" : "text-gray-400"
              }`}
            >
              <Calendar size={20} />
              <span className="text-xs">Bookings</span>
            </button>
            <button
              onClick={() => {
                setActiveTab("profile");
                setCurrentScreen("main");
              }}
              className={`flex flex-col items-center justify-center gap-1 ${
                activeTab === "profile" ? "text-gray-900" : "text-gray-400"
              }`}
            >
              <User size={20} />
              <span className="text-xs">Profile</span>
            </button>
          </div>
        </nav>
      )}
    </div>
  );
}
