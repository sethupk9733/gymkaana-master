import { Filter, Clock, CheckCircle, XCircle } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";

interface BookingsListProps {
  onBookingSelect: (bookingId: number) => void;
}

export function BookingsList({ onBookingSelect }: BookingsListProps) {
  const [activeFilter, setActiveFilter] = useState("pending");

  const bookings = [
    {
      id: 1,
      userName: "Rahul Sharma",
      planType: "Monthly Plan",
      date: "Today",
      time: "6:00 AM - 8:00 AM",
      status: "pending",
      amount: "₹2,500",
    },
    {
      id: 2,
      userName: "Priya Singh",
      planType: "Daily Pass",
      date: "Today",
      time: "8:00 AM - 10:00 AM",
      status: "pending",
      amount: "₹150",
    },
    {
      id: 3,
      userName: "Amit Kumar",
      planType: "Quarterly",
      date: "Yesterday",
      time: "7:00 AM - 9:00 AM",
      status: "confirmed",
      amount: "₹6,500",
    },
    {
      id: 4,
      userName: "Neha Patel",
      planType: "Monthly Plan",
      date: "2 days ago",
      time: "6:00 PM - 8:00 PM",
      status: "confirmed",
      amount: "₹2,500",
    },
    {
      id: 5,
      userName: "Vikram Joshi",
      planType: "Daily Pass",
      date: "3 days ago",
      time: "5:00 AM - 7:00 AM",
      status: "completed",
      amount: "₹150",
    },
  ];

  const filteredBookings = bookings.filter((booking) => booking.status === activeFilter);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-gray-400 text-white";
      case "confirmed":
        return "bg-gray-900 text-white";
      case "completed":
        return "bg-gray-200 text-gray-700";
      default:
        return "bg-gray-200 text-gray-700";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b-2 border-gray-300 px-6 py-4">
        <h1 className="text-xl">Bookings</h1>
        <p className="text-sm text-gray-500 mt-1">Manage member bookings</p>
      </div>

      {/* Filters */}
      <div className="bg-white border-b-2 border-gray-300 px-6 py-4">
        <div className="flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveFilter("pending")}
            className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap ${
              activeFilter === "pending"
                ? "bg-gray-900 text-white"
                : "bg-gray-100 text-gray-700"
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setActiveFilter("confirmed")}
            className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap ${
              activeFilter === "confirmed"
                ? "bg-gray-900 text-white"
                : "bg-gray-100 text-gray-700"
            }`}
          >
            Confirmed
          </button>
          <button
            onClick={() => setActiveFilter("completed")}
            className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap ${
              activeFilter === "completed"
                ? "bg-gray-900 text-white"
                : "bg-gray-100 text-gray-700"
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      {/* Bookings List */}
      <div className="px-6 py-6 space-y-3">
        {filteredBookings.map((booking) => (
          <div
            key={booking.id}
            className="bg-white border-2 border-gray-300 rounded-lg p-4"
          >
            {/* User Info */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-sm text-gray-600">{booking.userName.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="text-base mb-1">{booking.userName}</h3>
                  <p className="text-sm text-gray-600">{booking.planType}</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded text-xs ${getStatusColor(booking.status)}`}>
                {booking.status}
              </span>
            </div>

            {/* Booking Details */}
            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock size={14} />
                <span>{booking.date} • {booking.time}</span>
              </div>
              <p className="text-sm">
                <span className="text-gray-600">Amount: </span>
                <span>{booking.amount}</span>
              </p>
            </div>

            {/* Actions */}
            {booking.status === "pending" && (
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  className="h-10 border-2 border-gray-300"
                >
                  <XCircle size={16} className="mr-2" />
                  Reject
                </Button>
                <Button className="h-10 bg-gray-900 text-white hover:bg-gray-800">
                  <CheckCircle size={16} className="mr-2" />
                  Confirm
                </Button>
              </div>
            )}

            {booking.status !== "pending" && (
              <Button
                onClick={() => onBookingSelect(booking.id)}
                variant="outline"
                className="w-full h-10 border-2 border-gray-300"
              >
                View Details
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
