import { MapPin, Star, Eye, Edit, Plus, Search } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

interface GymsListProps {
  onGymSelect: (gymId: number) => void;
}

export function GymsList({ onGymSelect }: GymsListProps) {
  const gyms = [
    {
      id: 1,
      name: "FitZone Gym",
      address: "Sector 18, Noida",
      rating: 4.5,
      status: "active",
      members: 156,
    },
    {
      id: 2,
      name: "PowerHouse Fitness",
      address: "Connaught Place, Delhi",
      rating: 4.7,
      status: "active",
      members: 203,
    },
    {
      id: 3,
      name: "Elite Fitness Center",
      address: "Gurgaon Sector 29",
      rating: 4.3,
      status: "inactive",
      members: 89,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b-2 border-gray-300 px-6 py-4">
        <h1 className="text-xl">My Gyms</h1>
        <p className="text-sm text-gray-500 mt-1">Manage your gym listings</p>
      </div>

      {/* Search Bar */}
      <div className="bg-white border-b-2 border-gray-300 px-6 py-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <Input
            type="text"
            placeholder="Search gyms..."
            className="pl-10 h-11 border-2 border-gray-300"
          />
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-4">
        {/* Add Gym Button */}
        <Button className="w-full h-12 bg-gray-900 text-white hover:bg-gray-800">
          <Plus size={18} className="mr-2" />
          Add New Gym
        </Button>

        {/* Gym Cards */}
        <div className="space-y-4">
          {gyms.map((gym) => (
            <div key={gym.id} className="bg-white border-2 border-gray-300 rounded-lg overflow-hidden">
              {/* Image Placeholder */}
              <div className="w-full h-40 bg-gray-200"></div>

              {/* Content */}
              <div className="p-4">
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-base mb-1">{gym.name}</h3>
                    <div className="flex items-center gap-1 text-gray-600 mb-2">
                      <MapPin size={14} />
                      <span className="text-sm">{gym.address}</span>
                    </div>
                  </div>
                  <div
                    className={`px-3 py-1 rounded text-xs ${
                      gym.status === "active"
                        ? "bg-gray-900 text-white"
                        : "bg-gray-200 text-gray-600"
                    }`}
                  >
                    {gym.status}
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-1">
                    <Star size={14} className="text-gray-600" />
                    <span className="text-sm text-gray-600">{gym.rating}</span>
                  </div>
                  <div className="text-sm text-gray-600">{gym.members} members</div>
                </div>

                {/* Actions */}
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={() => onGymSelect(gym.id)}
                    variant="outline"
                    className="h-10 border-2 border-gray-300"
                  >
                    <Eye size={16} className="mr-2" />
                    View
                  </Button>
                  <Button
                    variant="outline"
                    className="h-10 border-2 border-gray-300"
                  >
                    <Edit size={16} className="mr-2" />
                    Edit
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
