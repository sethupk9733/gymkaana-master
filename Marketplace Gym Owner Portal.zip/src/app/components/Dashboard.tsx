import { Bell, Users, Activity, DollarSign, Clock, Plus, TrendingUp, Eye } from "lucide-react";
import { Button } from "./ui/button";

interface DashboardProps {
  onNavigateToNotifications: () => void;
  onNavigateToPayouts: () => void;
  onNavigateToQR: () => void;
}

export function Dashboard({ onNavigateToNotifications, onNavigateToPayouts, onNavigateToQR }: DashboardProps) {
  const kpis = [
    { label: "Active Members", value: "245", icon: Users, change: "+12%" },
    { label: "Today Check-ins", value: "48", icon: Activity, change: "+8%" },
    { label: "Revenue (Month)", value: "₹1.2L", icon: DollarSign, change: "+15%" },
    { label: "Pending Bookings", value: "7", icon: Clock, change: "-3%" },
  ];

  const recentActivity = [
    { type: "booking", user: "Rahul Sharma", action: "New booking - Monthly Plan", time: "5 min ago" },
    { type: "payment", user: "Priya Singh", action: "Payment received ₹2,500", time: "12 min ago" },
    { type: "booking", user: "Amit Kumar", action: "Booking confirmed", time: "25 min ago" },
    { type: "checkin", user: "Neha Patel", action: "Checked in", time: "1 hour ago" },
    { type: "payment", user: "Vikram Joshi", action: "Payment received ₹1,200", time: "2 hours ago" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b-2 border-gray-300 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="w-32 h-8 bg-gray-300 rounded"></div>
          </div>
          <button onClick={onNavigateToNotifications} className="relative">
            <Bell size={24} className="text-gray-700" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-gray-900 rounded-full text-white text-xs flex items-center justify-center">
              3
            </span>
          </button>
        </div>
        <div className="mt-4">
          <h1 className="text-xl">Welcome back, Owner</h1>
          <p className="text-sm text-gray-500 mt-1">Here's what's happening today</p>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {/* KPI Cards */}
        <div>
          <h2 className="text-base mb-4">Overview</h2>
          <div className="grid grid-cols-2 gap-4">
            {kpis.map((kpi, index) => (
              <div key={index} className="bg-white border-2 border-gray-300 rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center">
                    <kpi.icon size={20} className="text-gray-600" />
                  </div>
                  <span className={`text-xs ${kpi.change.startsWith('+') ? 'text-gray-700' : 'text-gray-500'}`}>
                    {kpi.change}
                  </span>
                </div>
                <p className="text-2xl mb-1">{kpi.value}</p>
                <p className="text-xs text-gray-500">{kpi.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-base mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            <Button className="h-20 bg-white border-2 border-gray-300 text-gray-900 hover:bg-gray-50 flex-col gap-2">
              <Plus size={20} />
              <span className="text-sm">Add Gym</span>
            </Button>
            <Button className="h-20 bg-white border-2 border-gray-300 text-gray-900 hover:bg-gray-50 flex-col gap-2">
              <Plus size={20} />
              <span className="text-sm">Add Plan</span>
            </Button>
            <Button onClick={onNavigateToPayouts} className="h-20 bg-white border-2 border-gray-300 text-gray-900 hover:bg-gray-50 flex-col gap-2">
              <Eye size={20} />
              <span className="text-sm">View Earnings</span>
            </Button>
            <Button onClick={onNavigateToQR} className="h-20 bg-white border-2 border-gray-300 text-gray-900 hover:bg-gray-50 flex-col gap-2">
              <Activity size={20} />
              <span className="text-sm">QR Check-in</span>
            </Button>
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h2 className="text-base mb-4">Recent Activity</h2>
          <div className="bg-white border-2 border-gray-300 rounded-lg divide-y-2 divide-gray-300">
            {recentActivity.map((activity, index) => (
              <div key={index} className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-xs text-gray-600">{activity.user.charAt(0)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{activity.user}</p>
                    <p className="text-sm text-gray-600 mt-1">{activity.action}</p>
                    <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
